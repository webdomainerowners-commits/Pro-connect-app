# ProConnect

A LinkedIn-style professional networking app for Android.

**Features:** sign-up, home feed (post, like, comment, repost, share, delete), network (invitations,
suggestions, connect/remove), jobs (search, filters, save, Easy Apply), messaging with simulated
replies, notifications, search, and an editable profile (about, skills, experience).
Light and dark themes. Works offline; all data is stored on the device (no backend).

The app is a web app in `www/`, packaged for Android with [Capacitor](https://capacitorjs.com).

## Get the APK (no installs, ~5 minutes)

1. Create a new GitHub repository and upload everything in this folder (keep `.github/workflows/`).
2. Open the repo's **Actions** tab → **Build Android APK** → **Run workflow**
   (it also runs on every push to `main`).
3. When it finishes, open the run and download the **ProConnect-debug-apk** artifact.
   Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, open it and allow "Install unknown apps" when asked.

## Build locally

Requirements: Node 20+, JDK 17, Android SDK (Android Studio).

```bash
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```

Or open the generated `android/` folder in Android Studio and press **Run**.

## Try it in a browser

```bash
npm run serve   # then open http://localhost:8080
```

On Android Chrome the page can also be installed via "Add to Home screen" (PWA).

## Before publishing to Google Play

- The debug APK is for testing. Build a signed release (`./gradlew assembleRelease` /
  `bundleRelease`) with your own keystore.
- Change `appId` in `capacitor.config.json` to your own reverse-domain id.
- Replace the launcher icons (`npx @capacitor/assets generate` with an `assets/icon.png`).
- This app has no server: accounts, posts, jobs and people are demo data stored locally.
  A real network needs a backend (auth, database, push notifications).
