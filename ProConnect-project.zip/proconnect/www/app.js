(() => {
'use strict';

/* ------------------------------------------------------------------ *
 *  ProConnect – a professional-networking app (feed, network, jobs,
 *  messaging, profiles). Runs fully offline; data lives in localStorage.
 * ------------------------------------------------------------------ */

const KEY = 'proconnect.v1';
const H = 3600e3, D = 24 * H;

/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nl = s => esc(s).replace(/\n/g, '<br>');
const uid = () => Math.random().toString(36).slice(2, 10);
const now = () => Date.now();
const rnd = a => a[Math.floor(Math.random() * a.length)];
const hue = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const initials = n => String(n).split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('') || '?';
function ago(t) {
  const s = (now() - t) / 1000;
  if (s < 60) return 'now';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  if (s < 604800) return Math.floor(s / 86400) + 'd';
  return Math.floor(s / 604800) + 'w';
}
const clock = t => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

const ICON = {
  home: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
  people: 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z',
  add: 'M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z',
  work: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z',
  chat: 'M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z',
  bell: 'M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z',
  search: 'M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
  like: 'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z',
  comment: 'M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18z',
  repost: 'M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z',
  send: 'M2.01 21L23 12 2.01 3 2 10l15 2-15 2z',
  check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
  bookmark: 'M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  adduser: 'M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'
};
const ic = (n, s = 24) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICON[n]}"/></svg>`;

/* ---------- demo data ---------- */
const PEOPLE = [
  { id: 'p1', name: 'Aisha Rahman', headline: 'Senior Product Manager at Northwind', company: 'Northwind', location: 'Dubai, UAE', about: 'Shipping B2B products that people actually enjoy using. Mentor, speaker, coffee enthusiast.', skills: ['Product Strategy', 'Roadmapping', 'User Research', 'Agile'], experience: [{ title: 'Senior Product Manager', company: 'Northwind', period: '2021 – Present' }, { title: 'Product Manager', company: 'Cloudbeam', period: '2017 – 2021' }] },
  { id: 'p2', name: 'Daniel Okafor', headline: 'Full-Stack Engineer · React, Node, AWS', company: 'Lumen Labs', location: 'Lagos, Nigeria', about: 'I build fast, reliable web platforms and love clean APIs.', skills: ['JavaScript', 'React', 'Node.js', 'AWS', 'PostgreSQL'], experience: [{ title: 'Full-Stack Engineer', company: 'Lumen Labs', period: '2020 – Present' }] },
  { id: 'p3', name: 'Mei Tanaka', headline: 'UX Designer building accessible products', company: 'Studio Kumo', location: 'Tokyo, Japan', about: 'Designing inclusive experiences. Accessibility advocate.', skills: ['UX Design', 'Figma', 'Accessibility', 'Prototyping'], experience: [{ title: 'Lead UX Designer', company: 'Studio Kumo', period: '2019 – Present' }] },
  { id: 'p4', name: 'Carlos Mendes', headline: 'Data Scientist | ML & Analytics', company: 'Atlas Analytics', location: 'São Paulo, Brazil', about: 'Turning messy data into decisions. Python, forecasting and experimentation.', skills: ['Python', 'Machine Learning', 'SQL', 'Statistics'], experience: [{ title: 'Data Scientist', company: 'Atlas Analytics', period: '2020 – Present' }] },
  { id: 'p5', name: 'Priya Nair', headline: 'Talent Acquisition Lead at Helix Group', company: 'Helix Group', location: 'Bengaluru, India', about: 'Connecting great people with great teams. Always hiring across engineering and design.', skills: ['Recruiting', 'Employer Branding', 'Interviewing', 'HR Analytics'], experience: [{ title: 'Talent Acquisition Lead', company: 'Helix Group', period: '2018 – Present' }] },
  { id: 'p6', name: 'Tom Becker', headline: 'Engineering Manager · Mobile Platforms', company: 'Orbit Apps', location: 'Berlin, Germany', about: 'Leading mobile teams. Kotlin, Swift and a lot of coffee.', skills: ['Leadership', 'Android', 'iOS', 'Mentoring'], experience: [{ title: 'Engineering Manager', company: 'Orbit Apps', period: '2019 – Present' }] },
  { id: 'p7', name: 'Sara Haddad', headline: 'Marketing Director · Growth & Brand', company: 'Brightpath', location: 'Amman, Jordan', about: 'Helping brands grow with clear stories and measurable campaigns.', skills: ['Brand Strategy', 'SEO', 'Content Marketing', 'Analytics'], experience: [{ title: 'Marketing Director', company: 'Brightpath', period: '2020 – Present' }] },
  { id: 'p8', name: 'Liam Walsh', headline: 'Operations Analyst | Supply Chain', company: 'Cargoline', location: 'Dublin, Ireland', about: 'Making supply chains leaner and more resilient.', skills: ['Supply Chain', 'Excel', 'Process Improvement', 'Power BI'], experience: [{ title: 'Operations Analyst', company: 'Cargoline', period: '2021 – Present' }] }
];

const JOBS = [
  { id: 'j1', title: 'Senior Frontend Engineer', company: 'Lumen Labs', location: 'Remote', type: 'Full-time', mode: 'Remote', salary: '$90k – $120k', days: 1, skills: ['React', 'TypeScript', 'CSS'], desc: 'Own the web client of our analytics platform. You will work with design and product to ship accessible, fast interfaces and mentor mid-level engineers.' },
  { id: 'j2', title: 'Product Manager', company: 'Northwind', location: 'Dubai, UAE', type: 'Full-time', mode: 'Hybrid', salary: 'AED 28k – 38k / month', days: 2, skills: ['Roadmapping', 'Stakeholders', 'Analytics'], desc: 'Lead discovery and delivery for our B2B workflow suite. Define success metrics, prioritise the backlog and partner closely with engineering.' },
  { id: 'j3', title: 'UX Design Intern', company: 'Studio Kumo', location: 'Tokyo, Japan', type: 'Internship', mode: 'On-site', salary: '¥220k / month', days: 3, skills: ['Figma', 'Research', 'Prototyping'], desc: 'Join a small design team for six months. You will run usability sessions, build prototypes and contribute to our design system.' },
  { id: 'j4', title: 'Data Analyst', company: 'Atlas Analytics', location: 'Remote', type: 'Contract', mode: 'Remote', salary: '$45 – $60 / hour', days: 4, skills: ['SQL', 'Python', 'Dashboards'], desc: 'Build dashboards and ad-hoc analyses for clients in retail and logistics. 6-month contract with extension possible.' },
  { id: 'j5', title: 'Android Developer', company: 'Orbit Apps', location: 'Berlin, Germany', type: 'Full-time', mode: 'Hybrid', salary: '€65k – €85k', days: 5, skills: ['Kotlin', 'Jetpack Compose', 'Testing'], desc: 'Help us build the next generation of our consumer mobile app using Kotlin and Compose in a cross-functional squad.' },
  { id: 'j6', title: 'Marketing Manager', company: 'Brightpath', location: 'Amman, Jordan', type: 'Full-time', mode: 'On-site', salary: 'JOD 1.8k – 2.6k / month', days: 6, skills: ['Campaigns', 'SEO', 'Copywriting'], desc: 'Plan and run multi-channel campaigns, manage a small team and report on growth metrics to leadership.' },
  { id: 'j7', title: 'Supply Chain Intern', company: 'Cargoline', location: 'Dublin, Ireland', type: 'Internship', mode: 'Hybrid', salary: '€1.8k / month', days: 7, skills: ['Excel', 'Logistics', 'Analysis'], desc: 'Support the operations team with demand planning, supplier tracking and weekly performance reporting.' },
  { id: 'j8', title: 'Technical Recruiter', company: 'Helix Group', location: 'Remote', type: 'Contract', mode: 'Remote', salary: '$30 – $40 / hour', days: 8, skills: ['Sourcing', 'Interviewing', 'ATS'], desc: 'Partner with hiring managers to fill engineering and design roles. Own the full cycle from sourcing to offer.' },
  { id: 'j9', title: 'Backend Engineer (Node.js)', company: 'Lumen Labs', location: 'Lagos, Nigeria', type: 'Full-time', mode: 'Hybrid', salary: '$55k – $75k', days: 9, skills: ['Node.js', 'PostgreSQL', 'AWS'], desc: 'Design and scale APIs that handle millions of requests per day. Strong focus on testing, observability and clean architecture.' },
  { id: 'j10', title: 'Customer Success Specialist', company: 'Northwind', location: 'Remote', type: 'Full-time', mode: 'Remote', salary: '$38k – $50k', days: 10, skills: ['Communication', 'Onboarding', 'CRM'], desc: 'Be the voice of our customers. Onboard new accounts, run quarterly reviews and turn feedback into product improvements.' }
];

const REPLIES = [
  'Thanks for reaching out! Happy to chat.',
  'Sounds great — let’s find a time this week.',
  'Appreciate the message. Can you share a bit more context?',
  'Interesting! I’ll take a look and get back to you.',
  'Good to hear from you 👍'
];

function seed(me) {
  const t = now();
  return {
    me,
    connections: ['p1', 'p3'],
    invites: ['p5', 'p6'],
    pending: [],
    savedJobs: [],
    applied: [],
    posts: [
      { id: 's1', authorId: 'p1', ts: t - 2 * H, text: 'Three lessons from shipping our biggest release this year:\n\n1. Talk to customers before writing specs.\n2. Cut scope early, not late.\n3. Celebrate the boring wins — reliability is a feature.', likes: ['p2', 'p3', 'p4'], comments: [{ id: 'c1', authorId: 'p2', text: 'Number 3 is so underrated.', ts: t - H }], reposts: 4 },
      { id: 's2', authorId: 'p3', ts: t - 6 * H, text: 'Accessibility is not a checklist at the end of a project. Start with keyboard navigation and colour contrast on day one and everything downstream gets easier.', likes: ['p1'], comments: [], reposts: 2 },
      { id: 's3', authorId: 'p5', ts: t - 20 * H, text: 'We’re hiring! Helix Group has open roles in engineering, design and data. Check the Jobs tab and send me a message if you’d like a referral. 🚀', likes: ['p2', 'p6', 'p7'], comments: [{ id: 'c2', authorId: 'p4', text: 'Just applied, thanks Priya!', ts: t - 18 * H }], reposts: 9 },
      { id: 's4', authorId: 'p4', ts: t - 1.5 * D, text: 'Reminder: a model that’s 2% more accurate but impossible to explain often loses to a simpler one your stakeholders trust.', likes: ['p1', 'p8'], comments: [], reposts: 3 },
      { id: 's5', authorId: 'p6', ts: t - 3 * D, text: 'Our mobile team just moved to Jetpack Compose. Build times down, happiness up. Happy to share what we learned along the way.', likes: ['p2'], comments: [], reposts: 1 }
    ],
    chats: {
      p1: [{ from: 'them', text: 'Hi! Thanks for connecting 👋', ts: t - D }],
      p3: [{ from: 'them', text: 'Welcome to ProConnect! Let me know if you need design feedback.', ts: t - 2 * D }]
    },
    notifs: [
      { id: uid(), text: 'Aisha Rahman accepted your connection request', ts: t - 3 * H, read: false },
      { id: uid(), text: 'Priya Nair posted: “We’re hiring!”', ts: t - 20 * H, read: false },
      { id: uid(), text: 'New jobs match your profile', ts: t - 1 * D, read: true }
    ]
  };
}

/* ---------- state ---------- */
let S = load();
const ui = { tab: 'home', stack: [], jobQ: '', jobF: 'All', openC: {}, searchQ: '' };

function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } }
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* storage unavailable */ } }
const person = id => id === 'me' ? S.me : PEOPLE.find(p => p.id === id) || { id, name: 'Member', headline: '', skills: [], experience: [] };
const job = id => JOBS.find(j => j.id === id);
const unread = () => S ? S.notifs.filter(n => !n.read).length : 0;
const topOverlay = () => ui.stack[ui.stack.length - 1];
const notify = text => { S.notifs.unshift({ id: uid(), text, ts: now(), read: false }); };

/* ---------- small view parts ---------- */
const avatar = (p, s = 40) => `<span class="av" style="--s:${s}px;background:hsl(${hue(p.name)} 42% 40%)">${esc(initials(p.name))}</span>`;
const logoSq = c => `<span class="logo-sq" style="background:hsl(${hue(c)} 45% 38%)">${esc(c[0])}</span>`;
const personRow = (p, right = '') => `
  <div class="item">
    <span class="link" data-a="profile" data-id="${p.id}">${avatar(p, 52)}</span>
    <div class="grow link" data-a="profile" data-id="${p.id}">
      <div class="name clip">${esc(p.name)}</div>
      <div class="sub clip">${esc(p.headline)}</div>
      <div class="sub">${p.mutual ?? (hue(p.name) % 9 + 2)} mutual connections</div>
    </div>
    ${right}
  </div>`;

function postCard(p, withComments = true) {
  const a = person(p.authorId);
  const liked = p.likes.includes('me');
  const open = !!ui.openC[p.id];
  return `
  <article class="card post" data-post="${p.id}">
    <div class="head">
      <span class="link" data-a="profile" data-id="${a.id}">${avatar(a, 48)}</span>
      <div class="grow link" data-a="profile" data-id="${a.id}">
        <div class="name clip">${esc(a.name)}</div>
        <div class="sub clip">${esc(a.headline)}</div>
        <div class="sub">${ago(p.ts)} · 🌐</div>
      </div>
      ${p.authorId === 'me' ? `<button class="icon-btn" data-a="delPost" data-id="${p.id}" aria-label="Delete post">${ic('trash', 20)}</button>` : ''}
    </div>
    <p class="body">${nl(p.text)}</p>
    <div class="counts">👍 ${p.likes.length} · ${p.comments.length} comments · ${p.reposts} reposts</div>
    <div class="actions">
      <button class="${liked ? 'on' : ''}" data-a="like" data-id="${p.id}">${ic('like', 22)}Like</button>
      <button class="${open ? 'on' : ''}" data-a="toggleC" data-id="${p.id}">${ic('comment', 22)}Comment</button>
      <button class="${p.rep ? 'on' : ''}" data-a="repost" data-id="${p.id}">${ic('repost', 22)}Repost</button>
      <button data-a="share" data-id="${p.id}">${ic('send', 22)}Send</button>
    </div>
    ${withComments && open ? `
    <div class="comments">
      ${p.comments.map(c => { const ca = person(c.authorId); return `
        <div class="comment">${avatar(ca, 32)}
          <div class="bub"><div class="name">${esc(ca.name)} <span class="sub">· ${ago(c.ts)}</span></div><p>${nl(c.text)}</p></div>
        </div>`; }).join('')}
      <form class="cform" data-form="comment" data-id="${p.id}">
        ${avatar(S.me, 32)}
        <input name="text" placeholder="Add a comment…" maxlength="400" autocomplete="off" required>
        <button class="icon-btn" aria-label="Send comment">${ic('send', 22)}</button>
      </form>
    </div>` : ''}
  </article>`;
}

function jobRow(j) {
  const saved = S.savedJobs.includes(j.id), applied = S.applied.some(a => a.id === j.id);
  return `
  <div class="item">
    ${logoSq(j.company)}
    <div class="grow link" data-a="job" data-id="${j.id}">
      <div class="name clip">${esc(j.title)}</div>
      <div class="sub clip">${esc(j.company)} · ${esc(j.location)}</div>
      <div class="sub clip">${esc(j.mode)} · ${esc(j.type)} · ${j.days}d ago${applied ? ' · <b style="color:var(--good)">Applied</b>' : ''}</div>
    </div>
    <button class="icon-btn" style="color:${saved ? 'var(--brand)' : 'var(--muted)'}" data-a="saveJob" data-id="${j.id}" aria-label="Save job">${ic('bookmark')}</button>
  </div>`;
}

/* ---------- main screens ---------- */
const screens = {
  home() {
    const posts = S.posts.slice().sort((a, b) => b.ts - a.ts).map(p => postCard(p)).join('');
    return `
    <section class="card composer">
      <button class="ghost-input" data-a="compose">${avatar(S.me, 44)}<span class="txt">Start a post</span></button>
    </section>${posts}`;
  },

  network() {
    const inv = S.invites.map(person);
    const sug = PEOPLE.filter(p => !S.connections.includes(p.id) && !S.invites.includes(p.id) && !S.pending.some(x => x.id === p.id));
    const conns = S.connections.map(person);
    return `
    ${inv.length ? `<div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Invitations (${inv.length})</h3></div>${inv.map(p => personRow(p, `
      <div class="row">
        <button class="icon-btn" data-a="ignore" data-id="${p.id}" aria-label="Ignore">${ic('close')}</button>
        <button class="icon-btn" style="color:var(--brand)" data-a="accept" data-id="${p.id}" aria-label="Accept">${ic('check')}</button>
      </div>`)).join('')}</div>` : ''}
    <div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>People you may know</h3></div>
      ${sug.length ? sug.map(p => personRow(p, `<button class="btn sm" data-a="connect" data-id="${p.id}">Connect</button>`)).join('') : '<div class="empty">You’re connected with everyone here. 🎉</div>'}
    </div>
    ${S.pending.length ? `<div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Pending (${S.pending.length})</h3></div>${S.pending.map(x => personRow(person(x.id), '<span class="sub">Pending</span>')).join('')}</div>` : ''}
    <div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Your connections (${conns.length})</h3></div>
      ${conns.length ? conns.map(p => personRow(p, `<button class="icon-btn" data-a="chat" data-id="${p.id}" aria-label="Message">${ic('chat')}</button>`)).join('') : '<div class="empty">No connections yet.</div>'}
    </div>`;
  },

  jobs() {
    const filters = ['All', 'Remote', 'Full-time', 'Internship', 'Contract', 'Saved'];
    return `
    <div class="card" style="margin-bottom:0"><input id="jobq" type="search" placeholder="Search jobs, companies, skills" value="${esc(ui.jobQ)}" autocomplete="off"></div>
    <div class="chips">${filters.map(f => `<button class="chip ${ui.jobF === f ? 'on' : ''}" data-a="jobF" data-id="${f}">${f}</button>`).join('')}</div>
    <div class="list" id="joblist" style="margin-top:10px">${jobsList()}</div>`;
  },

  messages() {
    const rows = S.connections.map(id => {
      const msgs = S.chats[id] || [];
      return { p: person(id), last: msgs[msgs.length - 1] };
    }).sort((a, b) => (b.last?.ts || 0) - (a.last?.ts || 0));
    if (!rows.length) return '<div class="empty">Connect with people to start messaging.</div>';
    return `<div class="list">${rows.map(({ p, last }) => `
      <button class="item" data-a="chat" data-id="${p.id}">
        ${avatar(p, 52)}
        <div class="grow">
          <div class="name clip">${esc(p.name)}</div>
          <div class="sub clip">${last ? (last.from === 'me' ? 'You: ' : '') + esc(last.text) : 'Say hello 👋'}</div>
        </div>
        <span class="sub">${last ? ago(last.ts) : ''}</span>
      </button>`).join('')}</div>`;
  }
};

function jobsList() {
  const q = ui.jobQ.trim().toLowerCase();
  const list = JOBS.filter(j => {
    const f = ui.jobF;
    if (f === 'Remote' && j.mode !== 'Remote') return false;
    if (['Full-time', 'Internship', 'Contract'].includes(f) && j.type !== f) return false;
    if (f === 'Saved' && !S.savedJobs.includes(j.id)) return false;
    return !q || [j.title, j.company, j.location, j.skills.join(' ')].join(' ').toLowerCase().includes(q);
  });
  return list.length ? list.map(jobRow).join('') : '<div class="empty">No jobs match your search.</div>';
}

/* ---------- overlays ---------- */
const overlays = {
  profile(o) {
    const p = person(o.id), isMe = o.id === 'me';
    const conn = S.connections.includes(p.id), pend = S.pending.some(x => x.id === p.id), inv = S.invites.includes(p.id);
    const btns = isMe
      ? `<button class="btn primary" data-a="edit">${ic('edit', 18)}Edit profile</button>
         <button class="btn" data-a="myJobs">My jobs</button>`
      : conn ? `<button class="btn primary" data-a="chat" data-id="${p.id}">${ic('chat', 18)}Message</button><button class="btn plain" data-a="disconnect" data-id="${p.id}">Remove connection</button>`
      : pend ? '<button class="btn" disabled>Pending</button>'
      : inv ? `<button class="btn primary" data-a="accept" data-id="${p.id}">Accept</button><button class="btn plain" data-a="ignore" data-id="${p.id}">Ignore</button>`
      : `<button class="btn primary" data-a="connect" data-id="${p.id}">${ic('adduser', 18)}Connect</button>`;
    const posts = S.posts.filter(x => x.authorId === p.id).sort((a, b) => b.ts - a.ts);
    return {
      title: isMe ? 'My profile' : 'Profile',
      body: `
      <section class="card hero">
        <div class="cover"></div>
        <div class="in">
          ${avatar(p, 80)}
          <h2>${esc(p.name)}</h2>
          <div>${esc(p.headline || 'Add a headline')}</div>
          <div class="sub">${esc(p.location || '')}${isMe ? ` · ${S.connections.length} connections` : ''}</div>
          <div class="btns">${btns}</div>
        </div>
      </section>
      <section class="card"><h3>About</h3><p>${p.about ? nl(p.about) : '<span class="sub">Nothing here yet.</span>'}</p></section>
      <section class="card"><h3>Experience</h3>${(p.experience || []).length
        ? p.experience.map(e => `<div class="row" style="margin-bottom:10px">${logoSq(e.company || 'X')}<div><div class="name">${esc(e.title)}</div><div class="sub">${esc(e.company)}</div><div class="sub">${esc(e.period)}</div></div></div>`).join('')
        : '<span class="sub">No experience added.</span>'}</section>
      <section class="card"><h3>Skills</h3>${(p.skills || []).length ? p.skills.map(s => `<span class="tag">${esc(s)}</span>`).join('') : '<span class="sub">No skills added.</span>'}</section>
      <section class="card" style="margin-bottom:0"><h3>Activity</h3></section>
      ${posts.length ? posts.map(x => postCard(x)).join('') : '<div class="empty">No posts yet.</div>'}`
    };
  },

  edit() {
    const m = S.me;
    return {
      title: 'Edit profile',
      right: `<button class="btn primary sm" form="editForm">Save</button>`,
      cls: 'pad',
      body: `
      <form id="editForm" class="form" data-form="edit">
        <label>Full name<input name="name" value="${esc(m.name)}" maxlength="60" required></label>
        <label>Headline<input name="headline" value="${esc(m.headline)}" maxlength="100"></label>
        <label>Location<input name="location" value="${esc(m.location)}" maxlength="60"></label>
        <label>About<textarea name="about" maxlength="1000" style="min-height:110px">${esc(m.about)}</textarea></label>
        <label>Skills (comma separated)<input name="skills" value="${esc((m.skills || []).join(', '))}"></label>
        <label>Experience (one per line: Title | Company | Period)
          <textarea name="experience" style="min-height:110px">${esc((m.experience || []).map(e => [e.title, e.company, e.period].join(' | ')).join('\n'))}</textarea></label>
      </form>
      <div class="form" style="margin-top:22px">
        <button class="btn danger block" data-a="reset">Reset demo data</button>
        <button class="btn plain block" data-a="signout">Sign out &amp; erase</button>
      </div>`
    };
  },

  compose() {
    return {
      title: 'Create post',
      right: `<button class="btn primary sm" form="postForm">Post</button>`,
      cls: 'pad',
      body: `
      <div class="row" style="margin-bottom:12px">${avatar(S.me, 48)}<div><div class="name">${esc(S.me.name)}</div><div class="sub">Post to anyone</div></div></div>
      <form id="postForm" data-form="post">
        <textarea name="text" id="postText" placeholder="What do you want to talk about?" maxlength="1500" required></textarea>
      </form>`
    };
  },

  job(o) {
    const j = job(o.id);
    const saved = S.savedJobs.includes(j.id), applied = S.applied.find(a => a.id === j.id);
    return {
      title: 'Job',
      body: `
      <section class="card">
        <div class="row" style="margin-bottom:10px">${logoSq(j.company)}<div><h3 style="margin:0">${esc(j.title)}</h3><div class="sub">${esc(j.company)} · ${esc(j.location)}</div></div></div>
        <div class="sub">${esc(j.mode)} · ${esc(j.type)} · ${esc(j.salary)}</div>
        <div class="sub">Posted ${j.days} days ago</div>
        <div class="row" style="margin-top:14px">
          <button class="btn primary grow" data-a="apply" data-id="${j.id}" ${applied ? 'disabled' : ''}>${applied ? 'Applied ✓' : 'Easy Apply'}</button>
          <button class="btn" data-a="saveJob" data-id="${j.id}">${saved ? 'Saved ✓' : 'Save'}</button>
        </div>
      </section>
      <section class="card"><h3>About the job</h3><p>${nl(j.desc)}</p></section>
      <section class="card"><h3>Skills</h3>${j.skills.map(s => `<span class="tag">${esc(s)}</span>`).join('')}</section>`
    };
  },

  myJobs() {
    const sv = S.savedJobs.map(job), ap = S.applied.map(a => job(a.id));
    return {
      title: 'My jobs',
      body: `
      <div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Saved (${sv.length})</h3></div>${sv.length ? sv.map(jobRow).join('') : '<div class="empty">No saved jobs.</div>'}</div>
      <div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Applied (${ap.length})</h3></div>${ap.length ? ap.map(jobRow).join('') : '<div class="empty">No applications yet.</div>'}</div>`
    };
  },

  chat(o) {
    const p = person(o.id), msgs = S.chats[o.id] || [];
    return {
      title: p.name,
      cls: 'chat',
      body: `<div class="msgs">${chatBubbles(o.id)}</div>`,
      footer: `<form class="sheet-f" data-form="chat" data-id="${o.id}"><input id="chatin" name="text" placeholder="Write a message…" maxlength="500" autocomplete="off" required><button class="icon-btn" style="color:var(--brand)" aria-label="Send">${ic('send')}</button></form>`
    };
  },

  notifs() {
    return {
      title: 'Notifications',
      body: S.notifs.length
        ? `<div class="list">${S.notifs.map(n => `<div class="item ${n.read ? '' : 'unread'}"><span class="av" style="--s:40px;background:var(--brand)">${ic('bell', 20).replace('class="ic"', 'class="ic" style="fill:#fff"')}</span><div class="grow">${esc(n.text)}</div><span class="sub">${ago(n.ts)}</span></div>`).join('')}</div>`
        : '<div class="empty">You’re all caught up.</div>'
    };
  },

  search() {
    return {
      title: 'Search',
      body: `<div class="card" style="margin-bottom:0"><input id="sq" type="search" placeholder="Search people, jobs and posts" value="${esc(ui.searchQ)}" autocomplete="off"></div><div id="sresults">${searchResults()}</div>`
    };
  }
};

function chatBubbles(id) {
  const msgs = S.chats[id] || [];
  return msgs.length
    ? msgs.map(m => `<div class="bubble ${m.from}">${nl(m.text)}<small>${clock(m.ts)}</small></div>`).join('')
    : `<div class="empty">Start the conversation with ${esc(person(id).name.split(' ')[0])}.</div>`;
}

function searchResults() {
  const q = ui.searchQ.trim().toLowerCase();
  if (!q) return '<div class="empty">Type to search people, jobs and posts.</div>';
  const ppl = PEOPLE.filter(p => [p.name, p.headline, p.company, p.skills.join(' ')].join(' ').toLowerCase().includes(q));
  const jb = JOBS.filter(j => [j.title, j.company, j.location, j.skills.join(' ')].join(' ').toLowerCase().includes(q));
  const ps = S.posts.filter(p => p.text.toLowerCase().includes(q));
  if (!ppl.length && !jb.length && !ps.length) return '<div class="empty">No results found.</div>';
  return `
    ${ppl.length ? `<div class="list" style="margin-top:8px"><div class="card" style="margin:0;box-shadow:none"><h3>People</h3></div>${ppl.map(p => personRow(p)).join('')}</div>` : ''}
    ${jb.length ? `<div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Jobs</h3></div>${jb.map(jobRow).join('')}</div>` : ''}
    ${ps.length ? `<div class="list"><div class="card" style="margin:0;box-shadow:none"><h3>Posts</h3></div>${ps.map(p => `<div class="item link" data-a="profile" data-id="${p.authorId}"><div class="grow"><div class="name">${esc(person(p.authorId).name)}</div><div class="sub clip">${esc(p.text)}</div></div></div>`).join('')}</div>` : ''}`;
}

/* ---------- shell ---------- */
function onboarding() {
  return `
  <div class="onb">
    <img class="mark" src="icon.svg" alt="">
    <h1>ProConnect</h1>
    <p class="sub">Grow your network, find your next role and share ideas with professionals.</p>
    <form class="card form" data-form="signup">
      <label>Full name<input name="name" required maxlength="60" autocomplete="name"></label>
      <label>Headline<input name="headline" maxlength="100" placeholder="e.g. Software Engineer at Acme"></label>
      <label>Location<input name="location" maxlength="60" placeholder="City, Country"></label>
      <button class="btn primary block">Join now</button>
    </form>
    <small class="sub">Demo app · everything is stored on this device only.</small>
  </div>`;
}

function render(keep = true) {
  const app = $('#app');
  if (!S) { app.innerHTML = onboarding(); return; }
  const m = $('.main'), sb = $('.sheet-b');
  const prev = { m: m ? m.scrollTop : 0, s: sb ? sb.scrollTop : 0 };
  const o = topOverlay();
  const ov = o ? overlays[o.t](o) : null;
  const nav = [['home', 'Home', 'home'], ['network', 'Network', 'people'], ['post', 'Post', 'add'], ['jobs', 'Jobs', 'work'], ['messages', 'Messages', 'chat']];
  app.innerHTML = `
    <header class="topbar">
      <button class="icon-btn" data-a="profile" data-id="me" aria-label="My profile">${avatar(S.me, 34)}</button>
      <button class="search-pill" data-a="search">${ic('search', 20)}<span>Search</span></button>
      <button class="icon-btn" data-a="notifs" aria-label="Notifications">${ic('bell')}<span class="badge" data-n="${unread()}">${unread() || ''}</span></button>
    </header>
    <main class="main">${screens[ui.tab]()}</main>
    <nav class="nav">${nav.map(([id, label, icon]) => `<button class="${ui.tab === id ? 'on' : ''}" data-a="tab" data-id="${id}">${ic(icon)}<span>${label}</span></button>`).join('')}</nav>
    ${ov ? `<div class="sheet" role="dialog" aria-label="${esc(ov.title)}">
      <header class="sheet-h"><button class="icon-btn" data-a="close" aria-label="Back">${ic('back')}</button><h2 class="clip">${esc(ov.title)}</h2><div>${ov.right || ''}</div></header>
      <div class="sheet-b ${ov.cls || ''}">${ov.body}</div>${ov.footer || ''}
    </div>` : ''}`;
  const nm = $('.main'), ns = $('.sheet-b');
  if (keep) { nm.scrollTop = prev.m; if (ns) ns.scrollTop = prev.s; }
  if (ns && o.t === 'chat') ns.scrollTop = ns.scrollHeight;
  if (o && o.t === 'chat') $('#chatin')?.focus();
  if (o && o.t === 'compose') $('#postText')?.focus();
  if (o && o.t === 'search') { const el = $('#sq'); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } }
}

/* Re-render from a timer without clobbering whatever the user is typing */
function softRender() {
  const a = document.activeElement;
  if (a && /^(INPUT|TEXTAREA)$/.test(a.tagName)) {
    const b = $('.topbar .badge');
    if (b) { b.dataset.n = unread(); b.textContent = unread() || ''; }
    return;
  }
  render(true);
}

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), 2200);
}

const open = o => { ui.stack.push(o); render(false); };
const close = () => { ui.stack.pop(); render(true); };

/* ---------- actions ---------- */
const actions = {
  tab(el) {
    if (el.dataset.id === 'post') return open({ t: 'compose' });
    ui.tab = el.dataset.id; ui.stack = []; render(false);
  },
  close,
  compose: () => open({ t: 'compose' }),
  search: () => { ui.searchQ = ''; open({ t: 'search' }); },
  profile: el => open({ t: 'profile', id: el.dataset.id }),
  edit: () => open({ t: 'edit' }),
  myJobs: () => open({ t: 'myJobs' }),
  job: el => open({ t: 'job', id: el.dataset.id }),
  chat(el) { if (topOverlay()?.t === 'chat') ui.stack.pop(); open({ t: 'chat', id: el.dataset.id }); },
  notifs() { S.notifs.forEach(n => n.read = true); save(); open({ t: 'notifs' }); },

  like(el) {
    const p = S.posts.find(x => x.id === el.dataset.id); if (!p) return;
    const i = p.likes.indexOf('me');
    if (i < 0) p.likes.push('me'); else p.likes.splice(i, 1);
    save(); render();
  },
  toggleC(el) { ui.openC[el.dataset.id] = !ui.openC[el.dataset.id]; render(); },
  repost(el) {
    const p = S.posts.find(x => x.id === el.dataset.id); if (!p) return;
    p.rep = !p.rep; p.reposts += p.rep ? 1 : -1;
    save(); render(); toast(p.rep ? 'Reposted' : 'Repost removed');
  },
  share(el) {
    const p = S.posts.find(x => x.id === el.dataset.id); if (!p) return;
    const text = `${person(p.authorId).name}: ${p.text}`;
    if (navigator.share) navigator.share({ text }).catch(() => {});
    else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast('Copied to clipboard'), () => toast('Unable to share'));
    else toast('Sharing is not supported here');
  },
  delPost(el) {
    if (!confirm('Delete this post?')) return;
    S.posts = S.posts.filter(x => x.id !== el.dataset.id); save(); render(); toast('Post deleted');
  },

  connect(el) {
    const id = el.dataset.id;
    if (S.pending.some(x => x.id === id) || S.connections.includes(id)) return;
    S.pending.push({ id, ts: now() }); save(); render(); toast('Invitation sent');
  },
  accept(el) {
    const id = el.dataset.id;
    S.invites = S.invites.filter(x => x !== id);
    if (!S.connections.includes(id)) S.connections.push(id);
    save(); render(); toast('You are now connected');
  },
  ignore(el) { S.invites = S.invites.filter(x => x !== el.dataset.id); save(); render(); },
  disconnect(el) {
    if (!confirm('Remove this connection?')) return;
    S.connections = S.connections.filter(x => x !== el.dataset.id); save(); render(); toast('Connection removed');
  },

  jobF(el) { ui.jobF = el.dataset.id; render(); },
  saveJob(el) {
    const id = el.dataset.id, i = S.savedJobs.indexOf(id);
    if (i < 0) S.savedJobs.push(id); else S.savedJobs.splice(i, 1);
    save(); render(); toast(i < 0 ? 'Job saved' : 'Removed from saved');
  },
  apply(el) {
    const j = job(el.dataset.id);
    if (S.applied.some(a => a.id === j.id)) return;
    S.applied.push({ id: j.id, ts: now() });
    notify(`Your application to ${j.company} (${j.title}) was submitted`);
    save(); render(); toast('Application submitted');
  },

  reset() {
    if (!confirm('Reset all demo data? Your profile is kept.')) return;
    S = seed(S.me); save(); ui.stack = []; ui.tab = 'home'; render(false); toast('Demo data reset');
  },
  signout() {
    if (!confirm('Sign out and erase everything on this device?')) return;
    try { localStorage.removeItem(KEY); } catch { /* ignore */ }
    S = null; ui.stack = []; ui.tab = 'home'; render(false);
  }
};

const forms = {
  signup(fd) {
    const name = (fd.name || '').trim(); if (!name) return;
    S = seed({ id: 'me', name, headline: (fd.headline || '').trim(), location: (fd.location || '').trim(), about: '', skills: [], experience: [] });
    save(); render(false);
  },
  post(fd) {
    const text = (fd.text || '').trim(); if (!text) return;
    const id = uid();
    S.posts.unshift({ id, authorId: 'me', text, ts: now(), likes: [], comments: [], reposts: 0 });
    save(); ui.stack = []; ui.tab = 'home'; render(false); toast('Posted');
    setTimeout(() => {
      const p = S.posts.find(x => x.id === id); if (!p) return;
      const pool = S.connections.length ? S.connections.map(person) : PEOPLE;
      const who = rnd(pool);
      if (!p.likes.includes(who.id)) p.likes.push(who.id);
      notify(`${who.name} liked your post`); save(); softRender();
    }, 4000);
  },
  comment(fd, f) {
    const p = S.posts.find(x => x.id === f.dataset.id); const text = (fd.text || '').trim();
    if (!p || !text) return;
    p.comments.push({ id: uid(), authorId: 'me', text, ts: now() }); save(); render();
  },
  chat(fd, f) {
    const id = f.dataset.id, text = (fd.text || '').trim(); if (!text) return;
    (S.chats[id] = S.chats[id] || []).push({ from: 'me', text, ts: now() }); save(); render();
    setTimeout(() => {
      S.chats[id].push({ from: 'them', text: rnd(REPLIES), ts: now() });
      const o = topOverlay(), inChat = o && o.t === 'chat' && o.id === id;
      if (!inChat) notify(`New message from ${person(id).name}`);
      save();
      const box = $('.msgs');
      if (inChat && box) {           // update bubbles only, so the typing field keeps focus
        box.innerHTML = chatBubbles(id);
        const sb = $('.sheet-b'); if (sb) sb.scrollTop = sb.scrollHeight;
      } else softRender();
    }, 1600);
  },
  edit(fd) {
    const m = S.me;
    m.name = (fd.name || '').trim() || m.name;
    m.headline = (fd.headline || '').trim();
    m.location = (fd.location || '').trim();
    m.about = (fd.about || '').trim();
    m.skills = (fd.skills || '').split(',').map(s => s.trim()).filter(Boolean).slice(0, 30);
    m.experience = (fd.experience || '').split('\n').map(l => l.trim()).filter(Boolean).slice(0, 20).map(l => {
      const [title = '', company = '', period = ''] = l.split('|').map(s => s.trim());
      return { title, company, period };
    });
    save(); ui.stack.pop(); render(true); toast('Profile updated');
  }
};

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-a]');
  if (!el || el.disabled) return;
  const fn = actions[el.dataset.a];
  if (fn) { e.preventDefault(); fn(el); }
});

document.addEventListener('submit', e => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  const fn = forms[f.dataset.form];
  if (fn) fn(Object.fromEntries(new FormData(f)), f);
});

document.addEventListener('input', e => {
  if (e.target.id === 'jobq') { ui.jobQ = e.target.value; const l = $('#joblist'); if (l) l.innerHTML = jobsList(); }
  if (e.target.id === 'sq') { ui.searchQ = e.target.value; const r = $('#sresults'); if (r) r.innerHTML = searchResults(); }
});

/* Pending invitations get accepted after a few seconds (simulated network) */
setInterval(() => {
  if (!S || !S.pending.length) return;
  const due = S.pending.filter(x => now() - x.ts > 5000);
  if (!due.length) return;
  due.forEach(x => {
    S.pending = S.pending.filter(y => y.id !== x.id);
    if (!S.connections.includes(x.id)) S.connections.push(x.id);
    const p = person(x.id);
    notify(`${p.name} accepted your connection request`);
    (S.chats[x.id] = S.chats[x.id] || []).push({ from: 'them', text: 'Thanks for connecting! 👋', ts: now() });
  });
  save(); softRender();
}, 2000);

/* Android hardware back button (Capacitor App plugin): close overlays first, then leave */
const CapApp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
if (CapApp && CapApp.addListener) {
  CapApp.addListener('backButton', () => {
    if (ui.stack.length) close();
    else if (ui.tab !== 'home') { ui.tab = 'home'; render(false); }
    else CapApp.exitApp();
  });
}

if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !window.Capacitor) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

render(false);
})();
